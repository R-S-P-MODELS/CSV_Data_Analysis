a=`apt list r-base|head -n 2|tail -n 1|awk '{print $NF}'`
echo "verificando instalação do R"
if [ $a != "[installed]" ] 
then 
echo "Iniciando instalação do R"
apt get install r-base 
echo "R instalado"

fi
echo "O software tem como dependencia o ggplot2,plotly e shiny, caso não possua os pacotes a primeira execução os instalará antes de inicializar o programa."
echo "Copiando os pacotes"
mkdir ~/APP_LOCAL
cp  code/*.R ~/APP_LOCAL
cp code/inicializa_local.R ~/APP_LOCAL
cp code/CSV_ANALYSIS ~
echo "Processo finalizado"
echo "Arquivo de execução na sua pasta pessoal chamado CSV ANALYSIS"
