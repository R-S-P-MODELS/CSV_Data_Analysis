require(shiny)
#runApp("app.R",host="0.0.0.0",port=4141,launch.browser=TRUE)
runApp("app.R",launch.browser=TRUE)
